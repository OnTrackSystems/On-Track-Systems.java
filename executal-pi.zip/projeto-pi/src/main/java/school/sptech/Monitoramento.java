package school.sptech;

import java.util.Random;

public class Monitoramento {
    private float cpu;
    private float ram;
    private float disco;
    private Random random;

    public Monitoramento() {
        random = new Random();
    }

    public void gerarValores() {
        cpu = gerarValorAleatorio();
        ram = gerarValorAleatorio();
        disco = gerarValorAleatorio();
    }

    private float gerarValorAleatorio() {
        return Math.round(random.nextFloat() * 1000) / 10.0f;
    }

    public float getCpu() {
        return cpu;
    }

    public float getRam() {
        return ram;
    }

    public float getDisco() {
        return disco;
    }
}
