package school.sptech;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Monitoramento monitor = new Monitoramento();
        List<String> alertas = new ArrayList<>();
        LocalDateTime dataHoraAtual = LocalDateTime.now();
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String dtHoraFormatada = dataHoraAtual.format(formatador);

        boolean executando = true;

        while (executando) {
            System.out.println("\n--- MENU DE MONITORAMENTO ---");
            System.out.println("1 - Iniciar captura");
            System.out.println("2 - Exibir alertas capturados");
            System.out.println("3 - Encerrar programa");
            System.out.print("Escolha: ");
            int opcao = leitor.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("\nIniciando captura (10 coletas, uma a cada 2 segundos)...\n");

                    long ultimaCaptura = System.currentTimeMillis();

                    int totalCapturas = 10;
                    int capturasRealizadas = 0;

                    while (capturasRealizadas < totalCapturas) {
                        long agora = System.currentTimeMillis();
                        if (agora - ultimaCaptura >= 2000) {
                            ultimaCaptura = agora;
                            capturasRealizadas++;

                            monitor.gerarValores();

                            float cpu = monitor.getCpu();
                            float ram = monitor.getRam();
                            float disco = monitor.getDisco();

                            System.out.printf("Captura %d - CPU: %.1f%% | RAM: %.1f%% | DISCO: %.1f%% - Data Hora: %s%n\n",
                                    capturasRealizadas, cpu, ram, disco, dtHoraFormatada);

                            if (cpu > 90) {
                                String alerta = String.format("ALERTA: CPU acima de 90%% (%.1f%%) | Data Hora: %s%n", cpu, dtHoraFormatada);
                                System.out.println(alerta);
                                alertas.add(alerta);
                            }

                            if (ram > 85) {
                                String alerta = String.format("ALERTA: RAM acima de 85%% (%.1f%%) | Data Hora: %s%n", ram, dtHoraFormatada);
                                System.out.println(alerta);
                                alertas.add(alerta);
                            }

                            if (disco > 80) {
                                String alerta = String.format("ALERTA: DISCO acima de 80%% (%.1f%%) | Data Hora: %s%n", disco, dtHoraFormatada);
                                System.out.println(alerta);
                                alertas.add(alerta);
                            }
                        }
                    }

                    System.out.println("Captura finalizada. Retornando ao menu...\n");
                    break;

                case 2:
                    System.out.println("\n--- ALERTAS CAPTURADOS ---");
                    if (alertas.isEmpty()) {
                        System.out.println("Nenhum alerta registrado.");
                    } else {
                        for (String alerta : alertas) {
                            System.out.println(alerta);
                        }
                    }
                    break;

                case 3:
                    executando = false;
                    System.out.println("Encerrando o programa...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        }

        leitor.close();
    }
}
